# Symfony

This plugin provides completion for [Symfony](https://symfony.com/).

To use it add symfony to the plugins array in your zshrc file.

```bash
plugins=(... symfony)
```
